ZAHRA BIO — BOUTIQUE AVEC STOCKAGE PERMANENT
1. Créez un projet Supabase.
2. Exécutez supabase_setup.sql dans SQL Editor.
3. Créez votre compte administrateur dans Authentication > Users.
4. Remplacez les deux valeurs de config.js par l'URL du projet et la clé anon/public.
5. Publiez le dossier sur GitHub Pages, Netlify ou Vercel.
La clé service_role ne doit jamais être mise dans le site.
